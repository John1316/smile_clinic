Product Name
---------------
Frest - Clean & Minimal Bootstrap Admin Dashboard Template


Product Description
-------------------
Frest admin is super flexible, powerful, clean & modern responsive bootstrap admin template with unlimited possibilities. It includes 4 pre-built templates with organized folder structure, clean & commented code, 100+ pages, 70+ components, 50+ charts, 50+ advance cards (widgets) and many more.


Online Documentation
--------------------
You will find documentation in your downloaded zip file from ThemeForest. You can access documentation online as well.
Documentation URL: https://pixinvent.com/demo/frest-clean-bootstrap-admin-dashboard-template/documentation

Change Log
----------
Read CHANGELOG.md file
